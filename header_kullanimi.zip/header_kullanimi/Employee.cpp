#include <iostream>
#include "Employee.h"

using namespace std;

	void Employee:: showInfos()
	{
		cout << "ID: " << Employee::id << endl;
		cout << "NAME: : " << Employee::name << endl;
		cout << "SALARY: " << Employee::salary << endl;
	}
