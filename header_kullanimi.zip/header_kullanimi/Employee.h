#ifndef EMLOYEE_HPP
#define EMPLOYEE_HPP
//#include <iostream>
using namespace std;

class Employee
{
public:
	string name;
	int id;
	int salary;
	void showInfos();
	
};
#endif 

