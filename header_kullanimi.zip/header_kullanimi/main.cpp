﻿#include <iostream>
using namespace std;
#include "Employee.h"

int main()
{
	Employee e1;
	e1.id = 15;
	e1.name =" Ali";
	e1.salary = 5000;
	e1.showInfos();
}
